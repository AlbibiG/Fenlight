# -*- coding: utf-8 -*-
import os
import time
import pymysql

try:
    from caches.settings_cache import get_setting
except Exception:
    def get_setting(setting_id, fallback=''):
        return os.environ.get(setting_id.replace('fenlight.', 'FENLIGHT_').upper().replace('.', '_'), fallback)


def get_connection_config():
    return {
        'host': get_setting('fenlight.watch_history.server_ip', '127.0.0.1'),
        'port': int(get_setting('fenlight.watch_history.port', '3306')),
        'user': get_setting('fenlight.watch_history.username', 'root'),
        'password': get_setting('fenlight.watch_history.password', ''),
        'database': get_setting('fenlight.watch_history.database_name', 'fenlight'),
        'charset': 'utf8mb4',
        'autocommit': True,
    }


def connect():
    config = get_connection_config()
    return pymysql.connect(**config)


def initialize_history_database():
    conn = connect()
    try:
        with conn.cursor() as cursor:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS watch_history (
                    tmdb_id VARCHAR(255) NOT NULL,
                    media_type VARCHAR(64),
                    title VARCHAR(255),
                    start_time DATETIME,
                    end_time DATETIME,
                    progress_seconds INT,
                    total_length_seconds INT,
                    is_finished BOOL,
                    profile_name VARCHAR(255),
                    season_number INT,
                    episode_number INT,
                    show_title VARCHAR(255),
                    show_tmdb_id VARCHAR(255),
                    PRIMARY KEY (tmdb_id, media_type, profile_name)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')

            cursor.execute('SHOW COLUMNS FROM watch_history')
            columns = {row['Field'] for row in cursor.fetchall()}

            column_definitions = {
                'start_time': 'DATETIME',
                'end_time': 'DATETIME',
                'progress_seconds': 'INT',
                'total_length_seconds': 'INT',
                'is_finished': 'BOOL',
                'profile_name': 'VARCHAR(255)',
                'season_number': 'INT',
                'episode_number': 'INT',
                'show_title': 'VARCHAR(255)',
                'show_tmdb_id': 'VARCHAR(255)',
            }
            for column_name, column_type in column_definitions.items():
                if column_name not in columns:
                    cursor.execute('ALTER TABLE watch_history ADD COLUMN %s %s' % (column_name, column_type))

            if 'progress_seconds' in columns and 'total_length_seconds' in columns:
                cursor.execute("SHOW COLUMNS FROM watch_history LIKE 'progress_seconds'")
                progress_column = cursor.fetchone()
                if progress_column and 'int' not in str(progress_column['Type']).lower():
                    cursor.execute('ALTER TABLE watch_history MODIFY progress_seconds INT')

                cursor.execute("SHOW COLUMNS FROM watch_history LIKE 'total_length_seconds'")
                total_length_column = cursor.fetchone()
                if total_length_column and 'int' not in str(total_length_column['Type']).lower():
                    cursor.execute('ALTER TABLE watch_history MODIFY total_length_seconds INT')

            if 'is_finished' in columns:
                cursor.execute("SHOW COLUMNS FROM watch_history LIKE 'is_finished'")
                is_finished_column = cursor.fetchone()
                if is_finished_column and 'bool' not in str(is_finished_column['Type']).lower():
                    cursor.execute('ALTER TABLE watch_history MODIFY is_finished BOOL')

        conn.commit()
    finally:
        conn.close()


def is_enabled():
    return str(get_setting('fenlight.watch_history.enabled', 'true')).lower() == 'true'


def get_profile_name(profile_name=None):
    if profile_name:
        return profile_name
    configured_profile = get_setting('fenlight.watch_history.profile_name', 'default')
    return configured_profile or 'default'


def _normalize_value(value):
    if value in (None, ''):
        return None
    return value


def _to_datetime_string(value):
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if hasattr(value, 'strftime'):
        return value.strftime('%Y-%m-%d %H:%M:%S')
    if isinstance(value, (int, float)):
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(value)))
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())


def save_watch_history_entry(
    tmdb_id,
    media_type,
    title,
    start_time=None,
    end_time=None,
    progress_seconds=0,
    total_length_seconds=0,
    is_finished=False,
    profile=None,
    season_number=None,
    episode_number=None,
    show_title=None,
    show_tmdb_id=None,
):
    if not is_enabled():
        return False
    try:
        initialize_history_database()
        conn = connect()
        profile_name = get_profile_name(profile)
        if start_time is None:
            start_time = time.time()
        if end_time is None:
            end_time = time.time()
        with conn.cursor() as cursor:
            cursor.execute(
                'DELETE FROM watch_history WHERE tmdb_id = %s AND media_type = %s AND COALESCE(profile_name, "") = %s',
                (str(tmdb_id), media_type, profile_name),
            )
            cursor.execute(
                '''
                INSERT INTO watch_history (
                    tmdb_id,
                    media_type,
                    title,
                    start_time,
                    end_time,
                    progress_seconds,
                    total_length_seconds,
                    is_finished,
                    profile_name,
                    season_number,
                    episode_number,
                    show_title,
                    show_tmdb_id
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''',
                (
                    str(tmdb_id),
                    media_type,
                    title,
                    _to_datetime_string(start_time),
                    _to_datetime_string(end_time),
                    int(progress_seconds),
                    int(total_length_seconds),
                    bool(is_finished),
                    profile_name,
                    _normalize_value(season_number),
                    _normalize_value(episode_number),
                    _normalize_value(show_title),
                    _normalize_value(show_tmdb_id),
                ),
            )
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_resume_state(tmdb_id, media_type, profile_name=None):
    if not is_enabled():
        return None
    try:
        initialize_history_database()
        conn = connect()
        profile_name = get_profile_name(profile_name)
        with conn.cursor() as cursor:
            cursor.execute(
                '''
                SELECT tmdb_id, media_type, title, start_time, end_time, progress_seconds, total_length_seconds, is_finished, profile_name,
                       season_number, episode_number, show_title, show_tmdb_id
                FROM watch_history
                WHERE tmdb_id = %s AND media_type = %s AND COALESCE(profile_name, "") = %s
                ORDER BY end_time DESC
                LIMIT 1
                ''',
                (str(tmdb_id), media_type, profile_name),
            )
            row = cursor.fetchone()
        conn.close()
        if not row:
            return None
        return {
            'tmdb_id': row['tmdb_id'],
            'media_type': row['media_type'],
            'title': row['title'],
            'start_time': row['start_time'],
            'end_time': row['end_time'],
            'progress_seconds': row['progress_seconds'] or 0,
            'total_length_seconds': row['total_length_seconds'] or 0,
            'is_finished': bool(row['is_finished']),
            'profile_name': row['profile_name'],
            'season_number': row['season_number'],
            'episode_number': row['episode_number'],
            'show_title': row['show_title'],
            'show_tmdb_id': row['show_tmdb_id'],
        }
    except Exception:
        return None


def get_resume_percent(tmdb_id, media_type, profile_name=None):
    state = get_resume_state(tmdb_id, media_type, profile_name)
    if not state:
        return 0.0
    if state['is_finished']:
        return 100.0
    total = state.get('total_length_seconds') or 0
    if not total:
        return 0.0
    progress = state.get('progress_seconds') or 0
    if progress <= 0:
        return 0.0
    percent = round(min(99.0, (float(progress) / float(total)) * 100.0), 1)
    return percent


def mark_as_watched(tmdb_id, media_type, title, profile=None, season_number=None, episode_number=None, show_title=None, show_tmdb_id=None, total_length_seconds=0):
    return save_watch_history_entry(
        tmdb_id=tmdb_id,
        media_type=media_type,
        title=title,
        start_time=time.time(),
        end_time=time.time(),
        progress_seconds=int(total_length_seconds) if total_length_seconds else 0,
        total_length_seconds=int(total_length_seconds) if total_length_seconds else 0,
        is_finished=True,
        profile=profile,
        season_number=season_number,
        episode_number=episode_number,
        show_title=show_title,
        show_tmdb_id=show_tmdb_id,
    )
