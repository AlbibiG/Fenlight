import json
import urllib.request
import urllib.parse
from modules.settings import watch_history_api_address, watch_history_api_port, watch_history_api_username, watch_history_api_password, watch_history_api_key, watch_history_profile_name, watch_history_database_name
from modules.kodi_utils import logger

class WatchHistoryClient:
    def __init__(self):
        self.base_url = f"{watch_history_api_address()}:{watch_history_api_port()}/api"
        self.profile = watch_history_profile_name()

    def get_token(self):
        # 1. Try to use a cached/stored token first if available
        current_token = getattr(self, "_cached_token", None)
        
        if current_token:
            refresh_url = f"{self.base_url}/api/refresh"
            headers = {
                "Authorization": f"Bearer {current_token}",
                "X-API-Key": watch_history_api_key(),
                "Content-Type": "application/json"
            }
            req = urllib.request.Request(refresh_url, headers=headers, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=5) as response:
                    if response.status == 200:
                        data = json.loads(response.read().decode("utf-8"))
                        self._cached_token = data.get("access_token")
                        return self._cached_token
            except Exception as exc:
                logger(f"Token Refresh Failed, falling back to login: {exc}", level=logger.WARNING)

        # 2. Fall back to full login if no cached token or refresh failed
        login_url = f"{self.base_url}/api/login"
        payload = {
            "username": watch_history_api_username(),
            "password": watch_history_api_password(),
            "database": watch_history_database_name()
        }
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": watch_history_api_key()
        }
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(login_url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode("utf-8"))
                    self._cached_token = data.get("access_token")
                    return self._cached_token
        except Exception as exc:
            logger(f"API Login Failed: {exc}", level=logger.ERROR)
        
        return None

    def _request(self, endpoint, method="GET", data=None):
        token = self.get_token()
        url = f"{self.base_url}/{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        
        body = json.dumps(data).encode("utf-8") if data else None
        req = urllib.request.Request(url, data=body, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                logger(f"API Unauthorized [{endpoint}], token may be invalid.", level=logger.ERROR)
            else:
                logger(f"API Request Failed [{endpoint}]: {exc}", level=logger.ERROR)
        except Exception as exc:
            logger(f"API Request Failed [{endpoint}]: {exc}", level=logger.ERROR)
        return None

    # --- Historical Play / Records ---
    def record_historical_play(self, media_type, media_id, season=None, episode=None, title="", started="", ended="", play_event="watched", resume_point="", curr_time="", resume_id=0):
        payload = {
            "media_type": media_type,
            "media_id": media_id,
            "season": season,
            "episode": episode,
            "title": title,
            "started": started,
            "ended": ended,
            "play_event": play_event,
            "resume_point": resume_point,
            "curr_time": curr_time,
            "resume_id": resume_id,
            "profile": self.profile
        }
        return self._request("history/record", method="POST", data=payload)

    # --- Watched Info ---
    def get_watched_movies(self):
        params = urllib.parse.urlencode({"profile": self.profile})
        return self._request(f"watched/movies?{params}")

    def get_watched_info_tvshow(self, watched_indicators=2):
        params = urllib.parse.urlencode({"watched_indicators": watched_indicators, "profile": self.profile})
        return self._request(f"watched/tvshow/info?{params}")

    def get_watched_info_season(self, media_id):
        params = urllib.parse.urlencode({"media_id": media_id, "profile": self.profile})
        return self._request(f"watched/season/info?{params}")

    def get_watched_info_episode(self, media_id):
        params = urllib.parse.urlencode({"media_id": media_id, "profile": self.profile})
        return self._request(f"watched/episode/info?{params}")

    def get_recently_watched(self, media_type, short_list=1):
        params = urllib.parse.urlencode({"media_type": media_type, "short_list": short_list, "profile": self.profile})
        return self._request(f"watched/recently?{params}")

    # --- Hidden Progress ---
    def get_hidden_progress_items(self):
        params = urllib.parse.urlencode({"profile": self.profile})
        return self._request(f"hidden/progress?{params}")

    def update_hidden_progress_items(self, media_id, action):
        payload = {
            "media_id": media_id,
            "action": action,
            "profile": self.profile
        }
        return self._request("hidden/progress/update", method="POST", data=payload)

    # --- Bookmarks & Progress ---
    def get_bookmarks_movie(self, watched_indicators=2):
        params = urllib.parse.urlencode({"watched_indicators": watched_indicators, "profile": self.profile})
        return self._request(f"bookmarks/movies/info?{params}")

    def get_bookmarks_episode(self, media_id, season):
        params = urllib.parse.urlencode({"media_id": media_id, "season": season, "profile": self.profile})
        return self._request(f"bookmarks/episode/info?{params}")

    def get_in_progress_movies(self):
        params = urllib.parse.urlencode({"profile": self.profile})
        return self._request(f"progress/movies?{params}")

    def get_in_progress_episodes(self):
        params = urllib.parse.urlencode({"profile": self.profile})
        return self._request(f"progress/episodes?{params}")

    def set_bookmark(self, media_type, media_id, curr_time, total_time, title="", season=None, episode=None):
        payload = {
            "media_type": media_type,
            "media_id": media_id,
            "curr_time": curr_time,
            "total_time": total_time,
            "title": title,
            "season": season,
            "episode": episode,
            "profile": self.profile
        }
        return self._request("bookmarks/set", method="POST", data=payload)

    def erase_bookmark(self, media_type, media_id, season=None, episode=None, refresh="false"):
        payload = {
            "media_type": media_type,
            "media_id": media_id,
            "season": season,
            "episode": episode,
            "refresh": refresh,
            "profile": self.profile
        }
        return self._request("bookmarks/erase", method="POST", data=payload)

    def batch_erase_bookmark(self, insert_list, action):
        payload = {
            "insert_list": insert_list,
            "action": action,
            "profile": self.profile
        }
        return self._request("bookmarks/batch-erase", method="POST", data=payload)

    # --- Watch Status Management ---
    def watched_status_mark(self, media_type, media_id, action, season=None, episode=None, title="", last_played=None):
        payload = {
            "media_type": media_type,
            "media_id": media_id,
            "action": action,
            "season": season,
            "episode": episode,
            "title": title,
            "last_played": last_played,
            "profile": self.profile
        }
        return self._request("watched/status", method="POST", data=payload)

    def batch_watched_status_mark(self, insert_list, action):
        payload = {
            "insert_list": insert_list,
            "action": action,
            "profile": self.profile
        }
        return self._request("watched/batch-status", method="POST", data=payload)

    # --- TV Shows Next Episodes ---
    def get_next_episodes(self, nextep_content=0):
        params = urllib.parse.urlencode({"nextep_content": nextep_content, "profile": self.profile})
        return self._request(f"tvshows/next-episodes?{params}")