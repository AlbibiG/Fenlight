import json
import time
from ast import literal_eval
from os import path
import sqlite3 as database
from modules import kodi_utils

def table_creators():
	return {
'navigator_db': (
'CREATE TABLE IF NOT EXISTS navigator (list_name text, list_type text, list_contents text, unique (list_name, list_type))',),
'watched_db': (
'CREATE TABLE IF NOT EXISTS watched \
(db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress \
(db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, \
last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
'favorites_db': (
'CREATE TABLE IF NOT EXISTS favourites (db_type text not null, tmdb_id text not null, title text not null, unique (db_type, tmdb_id))',),
'settings_db': (
'CREATE TABLE IF NOT EXISTS settings (setting_id text not null unique, setting_type text, setting_default text, setting_value text)',),
'trakt_db': (
'CREATE TABLE IF NOT EXISTS trakt_data (id text unique, data text)',
'CREATE TABLE IF NOT EXISTS watched \
(db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress \
(db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, \
last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
'maincache_db': (
'CREATE TABLE IF NOT EXISTS maincache (id text unique, data text, expires integer)',),
'metacache_db': (
'CREATE TABLE IF NOT EXISTS metadata (db_type text not null, tmdb_id text not null, imdb_id text, tvdb_id text, meta text, expires integer, unique (db_type, tmdb_id))',
'CREATE TABLE IF NOT EXISTS season_metadata (tmdb_id text not null unique, meta text, expires integer)',
'CREATE TABLE IF NOT EXISTS function_cache (string_id text not null unique, data text, expires integer)'),
'debridcache_db': (
'CREATE TABLE IF NOT EXISTS debrid_data (hash text not null, debrid text not null, cached text, expires integer, unique (hash, debrid))',),
'lists_db': (
'CREATE TABLE IF NOT EXISTS lists (id text unique, data text, expires integer)',),


'tmdb_lists_db': (
'CREATE TABLE IF NOT EXISTS tmdb_lists (id text unique, data text, expires integer)',),


'external_db': (
'CREATE TABLE IF NOT EXISTS results_data (provider text not null, db_type text not null, tmdb_id text not null, title text, year integer, season text, episode text, results text, \
expires integer, unique (provider, db_type, tmdb_id, title, year, season, episode))',),
'discover_db': (
'CREATE TABLE IF NOT EXISTS discover (id text not null unique, db_type text not null, data text)',),
'episode_groups_db': (
'CREATE TABLE IF NOT EXISTS groups_data (tmdb_id text not null unique, data text)',),
'personal_lists_db': (
'CREATE TABLE IF NOT EXISTS personal_lists (name text unique, contents text, total integer, created text, sort_order integer)',)
		}

def locations():
	return {
'navigator_db': 'navigator.db', 'watched_db': 'watched.db', 'favorites_db': 'favourites.db', 'settings_db': 'settings.db', 'trakt_db': 'traktcache.db',
'maincache_db': 'maincache.db', 'metacache_db': 'metacache.db', 'debridcache_db': 'debridcache.db', 'lists_db': 'lists.db', 'tmdb_lists_db': 'tmdb_lists.db',
'discover_db': 'discover.db', 'external_db': 'external.db', 'episode_groups_db': 'episode_groups.db', 'personal_lists_db': 'personal_lists.db'
			}

def database_locations(database_name):
	return kodi_utils.translatePath(path.join(path.join(kodi_utils.addon_profile(), 'databases'), locations()[database_name]))

def make_database(database_name):
	dbcon = database.connect(database_locations(database_name))
	all_commands = table_creators()[database_name]
	for command in all_commands: dbcon.execute(command)
	dbcon.close()

def make_databases():
	databases_path = path.join(kodi_utils.addon_profile(), 'databases/')
	if not kodi_utils.path_exists(databases_path): kodi_utils.make_directory(databases_path)
	all_locations = locations()
	for database_name in all_locations:
		dbcon = database.connect(database_locations(database_name))
		all_commands = table_creators()[database_name]
		for command in all_commands: dbcon.execute(command)

def connect_database(database_name=None):
	kodi_utils.logger('connect_database', database_name)
	if database_name == 'mariadb':
		try:
			from caches.mariadb_cache import connect, MariaDBWatchedDatabase
			return MariaDBWatchedDatabase(connect)
		except Exception as exc:
			kodi_utils.logger('connect_database MariaDB', severity='high',error_message=str(exc))
			return False
	if database_name == 'mariadb_api':
		try:
			from apis.mariadb_api import WatchHistoryClient
			return WatchHistoryClient()
		except Exception as exc:
			kodi_utils.logger('connect_database MariaDB API', severity='high', error_message=str(exc))
			return False
	else:
		try:
			extra = {'factory': {'watched_db': WatchedSQLiteConnection, 'trakt_db': WatchedSQLiteConnection, 'personal_lists_db': PersonalListsSQLiteConnection}[database_name]} if database_name in ('watched_db', 'trakt_db', 'personal_lists_db') else {}
			dbcon = database.connect(database_locations(database_name), timeout=20, isolation_level=None, check_same_thread=False, **extra)
			dbcon.execute('PRAGMA synchronous = OFF')
			dbcon.execute('PRAGMA journal_mode = OFF')
			return dbcon
		except Exception as exc:
			kodi_utils.logger('connect_database SQLite', severity='high', error_message=str(exc))
			return False

def get_timestamp(offset=0):
	# Offset is in HOURS multiply by 3600 to get seconds
	return int(time.time()) + (offset*3600)

def remove_old_databases():
	databases_path = path.join(kodi_utils.addon_profile(), 'databases/')
	current_dbs = ('navigator.db', 'watched.db', 'favourites.db', 'traktcache.db', 'maincache.db', 'lists.db', 'tmdb_lists.db', 'discover.db', 'metacache.db', 'debridcache.db',
	'external.db', 'settings.db', 'episode_groups.db', 'personal_lists_db', 'episode_groups_db', 'personal_lists_db')
	try:
		files = kodi_utils.list_dirs(databases_path)[1]
		for item in files:
			if not item in current_dbs:
				try: kodi_utils.delete_file(databases_path + item)
				except: pass
	except: pass

def check_databases_integrity():
	integrity_check = {
	'settings_db': ('settings',),
	'navigator_db': ('navigator',),
	'watched_db': ('watched_status', 'progress'),
	'favorites_db': ('favourites',),
	'trakt_db': ('trakt_data', 'watched_status', 'progress'),
	'maincache_db': ('maincache',),
	'metacache_db': ('metadata', 'season_metadata', 'function_cache'),
	'lists_db': ('lists',),
	'tmdb_lists_db': ('tmdb_lists',),
	'discover_db': ('discover',),
	'debridcache_db': ('debrid_data',),
	'external_db': ('results_data',),
	'episode_groups_db': ('groups_data',),
	'personal_lists_db': ('personal_lists',)
			}
	def _process(database_name, tables):
		database_location = database_locations(database_name)
		try:
			dbcon = database.connect(database_location)
			for db_table in tables: dbcon.execute(command_base % db_table)
		except:
			database_errors.append(database_name)
			if kodi_utils.path_exists(database_location):
				try: dbcon.close()
				except: pass
				kodi_utils.delete_file(database_location)
	command_base = 'SELECT * FROM %s LIMIT 1'
	database_errors = []
	integ_check = integrity_check.items()
	for database_name, tables in integ_check: _process(database_name, tables)
	make_databases()
	if database_errors: kodi_utils.ok_dialog(text='[B]Following Databases Rebuilt:[/B][CR][CR]%s' % ', '.join(database_errors))
	else: kodi_utils.notification('No Corrupt or Missing Databases', time=3000)

def get_size(file):
		with kodi_utils.open_file(file) as f: s = f.size()
		return s

def clean_databases():
	from caches.external_cache import external_cache
	from caches.main_cache import main_cache
	from caches.lists_cache import lists_cache
	from caches.meta_cache import meta_cache
	from caches.debrid_cache import debrid_cache
	clean_cache_list = (('EXTERNAL CACHE', external_cache, database_locations('external_db')),
						('MAIN CACHE', main_cache, database_locations('maincache_db')), ('LISTS CACHE', lists_cache, database_locations('lists_db')),
						('TMDB LISTS CACHE', lists_cache, database_locations('tmdb_lists_db')), ('META CACHE', meta_cache, database_locations('metacache_db')),
						('DEBRID CACHE', debrid_cache, database_locations('debridcache_db')))
	results = []
	append = results.append
	for item in clean_cache_list:
		name, function, location = item
		start_bytes = get_size(location)
		result = function.clean_database()
		if not result:
			append('[B]%s: [COLOR red]FAILED[/COLOR][/B]' % name)
			continue
		end_bytes = get_size(location)
		saved_bytes = start_bytes - end_bytes
		append('[B]%s: [COLOR green]SUCCESS[/COLOR][/B][CR]    [B]Saved Size: %sMB[/B][CR]    Start Size/End Size: %sMB/%sMB' \
		% (name, round(float(saved_bytes)/1024/1024, 2), round(float(start_bytes)/1024/1024, 2), round(float(end_bytes)/1024/1024, 2)))
	return kodi_utils.show_text('Cache Clean Results', text='[CR]----------------------------------[CR]'.join(results), font_size='large')

def clear_cache(cache_type, silent=False):
	def _confirm(): return silent or kodi_utils.confirm_dialog()
	success = True
	if cache_type == 'meta':
		from caches.meta_cache import delete_meta_cache
		success = delete_meta_cache(silent=silent)
	elif cache_type == 'internal_scrapers':
		if not _confirm(): return
		from apis import easynews_api
		results = []
		results.append(easynews_api.clear_media_results_database())
		for item in ('pm_cloud', 'rd_cloud', 'ad_cloud', 'oc_cloud', 'ed_cloud', 'tb_cloud', 'folders'): results.append(clear_cache(item, silent=True))
		success = False not in results
	elif cache_type == 'external_scrapers':
		from caches.external_cache import external_cache
		from caches.debrid_cache import debrid_cache
		results = []
		for item in (external_cache, debrid_cache): results.append(item.clear_cache())
		success = False not in results
	elif cache_type == 'trakt':
		from caches.trakt_cache import clear_all_trakt_cache_data
		success = clear_all_trakt_cache_data(silent=silent)
	elif cache_type == 'imdb':
		if not _confirm(): return
		from apis.imdb_api import clear_imdb_cache
		success = clear_imdb_cache()
	elif cache_type == 'pm_cloud':
		if not _confirm(): return
		from apis.premiumize_api import Premiumize
		success = Premiumize.clear_cache()
	elif cache_type == 'rd_cloud':
		if not _confirm(): return
		from apis.real_debrid_api import RealDebrid
		success = RealDebrid.clear_cache()
	elif cache_type == 'ad_cloud':
		if not _confirm(): return
		from apis.alldebrid_api import AllDebrid
		success = AllDebrid.clear_cache()
	elif cache_type == 'oc_cloud':
		if not _confirm(): return
		from apis.offcloud_api import Offcloud
		success = Offcloud.clear_cache()
	elif cache_type == 'ed_cloud':
		if not _confirm(): return
		from apis.easydebrid_api import EasyDebrid
		success = EasyDebrid.clear_cache()
	elif cache_type == 'tb_cloud':
		if not _confirm(): return
		from apis.torbox_api import TorBox
		success = TorBox.clear_cache()
	elif cache_type == 'folders':
		if not _confirm(): return
		from caches.main_cache import main_cache
		success = main_cache.delete_all_folderscrapers()
	elif cache_type == 'list':
		if not _confirm(): return
		from caches.lists_cache import lists_cache
		success = lists_cache.delete_all_lists()
	elif cache_type == 'tmdb_list':
		if not _confirm(): return
		from caches.tmdb_lists import tmdb_lists_cache
		success = tmdb_lists_cache.clear_all()
	else:# main
		if not _confirm(): return
		from caches.main_cache import main_cache
		success = main_cache.delete_all()
	if not silent and success: kodi_utils.notification('Success')
	return success

def clear_all_cache():
	if not kodi_utils.confirm_dialog(): return
	progressDialog = kodi_utils.progress_dialog()
	line = 'Clearing....[CR]%s'
	caches = (('meta', 'Meta Cache'), ('internal_scrapers', 'Internal Scrapers Cache'), ('external_scrapers', 'External Scrapers Cache'),
			('trakt', 'Trakt Cache'), ('imdb', 'IMDb Cache'), ('list', 'List Data Cache'), ('tmdb_list', 'TMDb Personal List Cache'),
			('main', 'Main Cache'), ('pm_cloud', 'Premiumize Cloud'), ('rd_cloud', 'Real Debrid Cloud'), ('ad_cloud', 'All Debrid Cloud'),
			('oc_cloud', 'OffCloud Cloud'), ('ed_cloud', 'Easy Debrid Cloud'), ('tb_cloud', 'TorBox Cloud'))
	for count, cache_type in enumerate(caches, 1):
		try:
			progressDialog.update(line % (cache_type[1]), int(float(count) / float(len(caches)) * 100))
			clear_cache(cache_type[0], silent=True)
			kodi_utils.sleep(1000)
		except: pass
	progressDialog.close()
	kodi_utils.sleep(100)
	kodi_utils.ok_dialog(text='Success')

def refresh_cached_data(meta):
	from caches.meta_cache import meta_cache
	media_type, tmdb_id, imdb_id = meta['mediatype'], meta['tmdb_id'], meta['imdb_id']
	try: meta_cache.delete(media_type, 'tmdb_id', tmdb_id, meta)
	except: return kodi_utils.notification('Error')
	from apis.imdb_api import refresh_imdb_meta_data
	refresh_imdb_meta_data(imdb_id)
	kodi_utils.notification('Success')
	kodi_utils.kodi_refresh()

class BaseCache(object):
	def __init__(self, dbfile, table):
		self.table = table
		self.dbfile = dbfile

	def get(self, string):
		result = None
		try:
			current_time = get_timestamp()
			dbcon = connect_database(self.dbfile)
			cache_data = dbcon.execute('SELECT expires, data FROM %s WHERE id = ?' % self.table, (string,)).fetchone()
			if cache_data:
				if cache_data[0] > current_time:
					result = eval(cache_data[1])
				else: self.delete(string)
		except: pass
		return result

	def set(self, string, data, expiration=720):
		try:
			dbcon = connect_database(self.dbfile)
			expires = get_timestamp(expiration)
			dbcon.execute('INSERT OR REPLACE INTO %s(id, data, expires) VALUES (?, ?, ?)' % self.table, (string, repr(data), int(expires)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database(self.dbfile)
			dbcon.execute('DELETE FROM %s WHERE id = ?' % self.table, (string,))
			self.delete_memory_cache(string)
		except: pass

	def delete_memory_cache(self, string):
		kodi_utils.clear_property('fenlight.%s' % string)

	def manual_connect(self, dbfile):
		return connect_database(dbfile)

class SQLDatabaseWrapper:
	"""Wrapper for MariaDB access. Checks out a pooled connection per call so concurrent
	threads each get their own socket instead of racing on a single shared connection."""
	def __init__(self, connection_factory):
		self._connection_factory = connection_factory
		self.is_sql = True
	
	def _convert_query(self, query):
		"""Convert SQLite syntax to MariaDB syntax"""
		# NULL-safe IS ? must be converted before generic ? replacement
		query = query.replace(' IS ?', ' <=> %s')
		query = query.replace('?', '%s')
		query = query.replace('INSERT OR REPLACE', 'REPLACE')
		query = query.replace('INSERT OR IGNORE', 'INSERT IGNORE')
		return query
	
	def execute(self, query, params=None):
		"""Execute query on a per-call pooled connection and return a fully buffered cursor"""
		query = self._convert_query(query)
		connection = self._connection_factory()
		try:
			cursor = connection.cursor()
			if params:
				cursor.execute(query, params)
			else:
				cursor.execute(query)
			connection.commit()
			return cursor
		finally:
			# safe to release now: results are already buffered client-side by the cursor
			connection.close()
	
	def executemany(self, query, params_list):
		"""Execute query multiple times with different parameters on a per-call pooled connection"""
		query = self._convert_query(query)
		connection = self._connection_factory()
		try:
			cursor = connection.cursor()
			cursor.executemany(query, params_list)
			connection.commit()
			cursor.close()
		finally:
			connection.close()

class WatchedSQLiteConnection(database.Connection):
	"""Local SQLite watched database. Provides the same watched methods as the MariaDB and API databases."""
	def record_historical_play(self, media_type, media_id, season=None, episode=None, title='', started='', ended='', play_event='watched', resume_point='', curr_time='', resume_id=0):
		pass

	def get_watched_movies(self):
		return self.execute('SELECT media_id, title, last_played FROM watched WHERE db_type = ?', ('movie',)).fetchall()

	def get_watched_info_tvshow(self):
		return self.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id', ('episode',)).fetchall()

	def get_watched_info_season(self, media_id):
		return self.execute('SELECT season, COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND media_id = ? GROUP BY media_id, season', ('episode', str(media_id))).fetchall()

	def get_watched_info_episode(self, media_id):
		return self.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', ('episode', str(media_id))).fetchall()

	def get_recently_watched(self, media_type, short_list=1):
		if short_list:
			return self.execute('SELECT media_id, season, episode, title, last_played FROM watched WHERE db_type = ? ORDER BY last_played DESC', (media_type,)).fetchall()
		return self.execute('SELECT media_id, season, episode, title, last_played FROM watched WHERE db_type = ?', (media_type,)).fetchall()

	def get_hidden_progress_items(self):
		return self.execute('SELECT status FROM watched_status WHERE db_type = ?', ('hidden_progress_items',)).fetchone()[0]

	def update_hidden_progress_items(self, media_id, action):
		media_id = int(media_id)
		try: current_items = literal_eval(self.get_hidden_progress_items()) or []
		except: current_items = []
		if action == 'drop':
			if media_id not in current_items: current_items.append(media_id)
		elif media_id in current_items: current_items.remove(media_id)
		self.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?)', ('hidden_progress_items', 'hidden', repr(current_items)))

	def get_bookmarks_movie(self):
		return self.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()

	def get_bookmarks_episode(self, media_id, season):
		return self.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?',
			('episode', str(media_id), int(season))).fetchall()

	def get_in_progress_movies(self):
		return self.execute('SELECT media_id, title, last_played FROM progress WHERE db_type = ?', ('movie',)).fetchall()

	def get_in_progress_episodes(self):
		return self.execute('SELECT media_id, season, episode, resume_point, last_played, title FROM progress WHERE db_type = ?', ('episode',)).fetchall()

	def set_bookmark(self, media_type, media_id, curr_time, total_time, title='', season=None, episode=None):
		resume_point = round((float(curr_time) - 5) / float(total_time) * 100, 1)
		from modules.settings import date_offset
		from modules.utils import format_timestamp
		last_played = format_timestamp(offset=date_offset())
		self.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
			(media_type, media_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title))

	def erase_bookmark(self, media_type, media_id, season=None, episode=None, refresh='false'):
		self.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))

	def batch_erase_bookmark(self, insert_list, action=None):
		self.executemany('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', insert_list)

	def watched_status_mark(self, media_type, media_id, action, season=None, episode=None, title='', last_played=None):
		if action == 'mark_as_watched':
			from modules.settings import date_offset
			from modules.utils import format_timestamp
			last_played = last_played or format_timestamp(offset=date_offset())
			self.execute('INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?)', (media_type, media_id, season, episode, last_played, title))
		elif action == 'mark_as_unwatched':
			self.execute('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season IS ? and episode IS ?)', (media_type, media_id, season, episode))

	def batch_watched_status_mark(self, insert_list, action):
		if action == 'mark_as_watched':
			self.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)
		elif action == 'mark_as_unwatched':
			self.executemany('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season IS ? and episode IS ?)', insert_list)

	def get_next_episodes(self, nextep_content=0):
		if nextep_content == 0:
			return self.execute('''WITH cte AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY media_id ORDER BY season DESC, episode DESC) rn FROM watched WHERE db_type = ?)
								SELECT media_id, season, episode, title, last_played FROM cte WHERE rn = 1''', ('episode',)).fetchall()
		return self.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id', ('episode',)).fetchall()

class PersonalListsSQLiteConnection(database.Connection):
	"""Local SQLite personal lists database. Provides the same list methods as the MariaDB and API databases."""
	def make_list(self, list_name, sort_order):
		from modules.settings import date_offset
		from modules.utils import format_timestamp
		created = format_timestamp(offset=date_offset())
		self.execute('INSERT OR REPLACE INTO personal_lists VALUES (?, ?, ?, ?, ?)', (list_name, repr([]), 0, created, sort_order))

	def delete_list(self, list_name):
		self.execute('DELETE FROM personal_lists WHERE name=?', (list_name,))
		self.execute('VACUUM')

	def clear_list_contents(self, list_name):
		self.execute('UPDATE personal_lists SET contents=?, total=? WHERE name=?', (repr([]), '0', list_name))

	def update_list_details(self, list_name, sort_order, original_name):
		self.execute('UPDATE personal_lists SET name=?, sort_order=? WHERE name=?', (list_name, sort_order, original_name))

	def get_lists(self):
		return self.execute('SELECT name, total, sort_order FROM personal_lists').fetchall()

	def get_list(self, list_name):
		return eval(self.execute('SELECT contents FROM personal_lists WHERE name=?', (list_name,)).fetchone()[0])

	def _save_list(self, list_name, contents):
		self.execute('UPDATE personal_lists SET contents=?, total=? WHERE name=?', (repr(contents), len(contents), list_name))

	def add_list_item(self, list_name, item):
		contents = self.get_list(list_name)
		if str(item['media_id']) in [str(i['media_id']) for i in contents]: return False
		contents.append(item)
		self._save_list(list_name, contents)
		return True

	def remove_list_item(self, list_name, media_id):
		contents = self.get_list(list_name)
		new_contents = [i for i in contents if str(i['media_id']) != str(media_id)]
		if len(new_contents) == len(contents): return False
		self._save_list(list_name, new_contents)
		return True

	def add_many_list_items(self, list_name, items):
		contents = self.get_list(list_name)
		existing = set(str(i['media_id']) for i in contents)
		contents.extend(i for i in items if str(i['media_id']) not in existing)
		self._save_list(list_name, contents)
